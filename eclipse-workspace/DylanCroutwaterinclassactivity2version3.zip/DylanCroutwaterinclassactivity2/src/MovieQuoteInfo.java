// Dylan Croutwater
// 8/21/2024
// The filename is MovieQuoteInfo.java and the purpose is to print my favorite quote from a movie. 
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Black Panther");
		System.out.println("Wakanda forever.");
		System.out.println("The movie came out in 2018");
	}

}
