package edu.DylanCroutwater;
// Dylan Croutwater
// 8/21/2024
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Black Panther");
		System.out.println("Wakanda forever.");
		System.out.println("The movie came out in 2018");
	}

}
