// Dylan Croutwater
// 8/15/2024
// SongLyrics.java
// The purpose of this assignment is to print the beginning lyrics of one of my favorite songs.


public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Castle On The Hill.");
		System.out.println("When I was six years old, I broke my leg");
		System.out.println("I was runnin' from my brother and his friends");
		System.out.println("And tasted the sweet perfume of the mountain grass I rolled down");
		System.out.println("I was younger then, take me back to when I");
	}

}
