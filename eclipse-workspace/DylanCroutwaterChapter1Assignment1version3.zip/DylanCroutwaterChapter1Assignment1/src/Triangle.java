// Dylan Croutwater
// 8 / 21 / 2024
// Triangle.java
// The purpose of this module is to create and print a triangle using the letter T.
public class Triangle {

	public static void main(String[] args) {
		 System.out.println("      T");
		 System.out.println("     TTT");
		 System.out.println("    TTTTT");
		 System.out.println("   TTTTTTT");
		 System.out.println("  TTTTTTTTT");
		 System.out.println(" TTTTTTTTTTT");
		 System.out.println("TTTTTTTTTTTTT");
		 

	}

}
